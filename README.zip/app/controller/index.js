module.exports = {
    auth: {
        generate_twilio_token: require('./twilio/generate-token')
    }
}