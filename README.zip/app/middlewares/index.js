module.exports = {
    auth: {
        generate_twilio_token: require('../services/twilio/generatetoken')
    }
}