# Assignment API Document Link

https://documenter.getpostman.com/view/3561144/UUy38RiQ

Getting Started
---------------

The easiest way to get started is to clone the repository:

```bash
# Get the latest snapshot
git clone https://github.com/dipal0708/mongo-Assignment.git

# Install NPM dependencies
npm install

# Then simply start your app
node index.js
```
